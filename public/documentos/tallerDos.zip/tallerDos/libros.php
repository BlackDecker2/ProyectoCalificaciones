<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Libros</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://getbootstrap.com/docs/5.3/assets/css/docs.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
      body {
        background-image: url("biblioteca.jpg");
        background-size: cover;
        background-repeat: no-repeat;
        padding: 3rem;
        margin: 0;
        border: 0;
      }
      h1 {
        text-align: center;
        background-color: #b98f8f;
        margin-top: 0;
      }
      .accordion-button {
        position: relative;
        display: flex;
        align-items: center;
        width: 100%;
        padding: var(--bs-accordion-btn-padding-y) var(--bs-accordion-btn-padding-x);
        font-size: 1rem;
        color: var(--bs-accordion-btn-color);
        text-align: left;
        background-color: #6984ad;
        border: 0;
        border-radius: 0;
        overflow-anchor: none;
        transition: var(--bs-accordion-transition);
      }
      .accordion-button:hover {
        background-color: #7b5ba8;
      }
      .accordion-button::after {
        content: '\f068';
        font-family: 'Font Awesome 5 Free';
        font-weight: 900;
        font-size: 12px;
        position: absolute;
        top: 50%;
        right: 16px;
        transform: translateY(-50%);
        color: white;
        transition: transform 0.3s;
      }
      .accordion-button.collapsed::after {
        transform: translateY(-50%) rotate(-180deg);
      }
    </style>
  </head>
  <body>

  
    <h1>LIBROS</h1>

    <div class="accordion" id="accordionPanelsStayOpenExample">
      <div class="accordion-item">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="false" aria-controls="panelsStayOpen-collapseOne">
            Libros y Editoriales
          </button>
        </h2>
        <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse">
          <div class="accordion-body">
            <?php
              $conexion = mysqli_connect("localhost", "root", "", "baselibros") or die("Problemas con la conexión");
              $gpt = "SELECT * FROM editoriales JOIN libros";
              $resul = $conexion->query($gpt);

              if ($resul->num_rows > 0) {
                while ($row = $resul->fetch_assoc()) {
                  echo "Código: " . $row["codigo"] . "<br>";
                  echo "nombre: " . $row["nombre"] . "<br>";
                  echo "direccion: " . $row["direccion"] . "<br>";
                  echo "Título: " . $row["titulo"] . "<br>";
                  echo "Autor: " . $row["autor"] . "<br>";
                  echo "Codigo Editorial: " . $row["codigoeditorial"] . "<br>";
                  echo "Precio: " . $row["precio"] . "<br>";
                  echo "cantidad: " . $row["cantidad"] . "<br><br>";
                }
              } else {
                echo "No se encuentran resultados";
              }

              $conexion->close();
            ?>
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="false" aria-controls="panelsStayOpen-collapseTwo">
            Libros con mismo codigo 
          </button>
        </h2>
        <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse">
          <div class="accordion-body">
            <?php
              $conexion = mysqli_connect("localhost", "root", "", "baselibros") or die("Problemas con la conexión");
              $gpt = "SELECT * FROM libros as l JOIN editoriales as e on l.codigoeditorial=e.codigo";
              $resul = $conexion->query($gpt);

              if ($resul->num_rows > 0) {
                while ($row = $resul->fetch_assoc()) {
                   echo "Código: " . $row["codigo"] . "<br>";
                  echo "Titulo: " . $row["titulo"] . "<br>";
                  echo "Autor: " . $row["autor"] . "<br>";
                  echo "Codigo Editorial: " . $row["codigoeditorial"] . "<br>";
                  echo "Precio: " . $row["precio"] . "<br>";
                  echo "Cantidad: " . $row["cantidad"] . "<br>";
                  echo "Codigo: " . $row["codigo"] . "<br>";
                  echo "Nombre: " . $row["nombre"] . "<br>";
                  echo "Direccion: " . $row["direccion"] . "<br><br>";
                }
              } else {
                echo "No se encuentran resultados";
              }
              $conexion->close();
            ?>
          </div>
        </div>
      </div>

      <div class="accordion-item">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="false" aria-controls="panelsStayOpen-collapseThree">
            Libros por: Titulo, Autor, Nombre.
          </button>
        </h2>
        <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse">
          <div class="accordion-body">
            <?php
              $conexion = mysqli_connect("localhost", "root", "", "baselibros") or die("Problemas con la conexión");
              $gpt = "SELECT titulo,autor,nombre from libros as l
              join editoriales as e 
              on l.codigoeditorial=e.codigo;";
              $resul = $conexion->query($gpt);

              if ($resul->num_rows > 0) {
                while ($row = $resul->fetch_assoc()) {
                  echo "Titulo: " . $row['titulo'] . "<br>";
                  echo "Autor: " . $row['autor'] . "<br>";
                  echo "Nombre: " . $row['nombre'] . "<br><br>";
                  
                }
              } else {
                echo "No se encuentran resultados";
              }

              $conexion->close();
            ?>
          </div>
        </div>
      </div>

      <div class="accordion-item">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapsefour" aria-expanded="false" aria-controls="panelsStayOpen-collapsefour">
            Numero de libros
          </button>

          

        </h2>
        <div id="panelsStayOpen-collapsefour" class="accordion-collapse collapse">
          <div class="accordion-body">
            
            <?php
              $conexion = mysqli_connect("localhost", "root", "", "baselibros") or die("Problemas con la conexión");
              $gpt = "SELECT COUNT(DISTINCT titulo) AS contador FROM libros WHERE titulo IS NOT NULL";
              $resul = $conexion->query($gpt);

              if ($resul->num_rows > 0) {
                $row = $resul->fetch_assoc();
                $contador = $row["contador"];
                echo "El contador es: " . $contador;
              } else {
                echo "No se encuentran resultados";
              }

              $conexion->close();
            ?>
          </div>
        </div>
      </div>
      <h1>Taller Dos</h1>
    </div>
  </body>
</html>



